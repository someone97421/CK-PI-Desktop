import { build } from 'esbuild';
import { mkdir, mkdtemp, readFile, writeFile, cp, lstat, rm } from 'node:fs/promises';
import { dirname, resolve, join } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { retainArtifacts } from '../../../scripts/artifact-retention.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const repository = resolve(root, '../..');
const buildRoot = join(root, '.build');
await mkdir(buildRoot, { recursive: true });
const staging = await mkdtemp(join(buildRoot, 'plugin-'));
const tooling = join(root, '.build', 'tools');
const mode = process.argv.includes('--pack') ? 'pack' : process.argv.includes('--check') ? 'check' : 'build';

async function copyAssets(source, destination) {
  await cp(source, destination, {
    recursive: true,
    filter: async (path) => {
      if ((await lstat(path)).isSymbolicLink()) throw new Error(`插件资源不能包含符号链接：${path}`);
      return !/\.(?:js|map)$/.test(path);
    },
  });
}

let buildSucceeded = false;
try {
  await mkdir(staging, { recursive: true });
  await mkdir(tooling, { recursive: true });
  const manifest = JSON.parse(await readFile(join(root, 'manifest.json'), 'utf8'));
  for (const server of manifest.contributes?.mcpServers ?? []) {
    const permission = server.transport === 'stdio' ? 'mcp.server.local' : 'mcp.server.remote';
    if (!manifest.permissions?.includes(permission)) throw new Error(`${server.transport} MCP 服务需要权限 ${permission}`);
  }
  let versionFiles = [];
  if (mode === 'pack') {
    const packagePath = join(root, 'package.json');
    const lockPath = join(root, 'package-lock.json');
    const pkg = JSON.parse(await readFile(packagePath, 'utf8'));
    const lock = JSON.parse(await readFile(lockPath, 'utf8'));
    const parts = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(manifest.version);
    if (!parts || [pkg.version, lock.version, lock.packages?.['']?.version].some((version) => version !== manifest.version)) {
      throw new Error('插件版本必须是同步一致的 major.minor.patch，无法自动递增。');
    }
    const nextVersion = `${parts[1]}.${parts[2]}.${BigInt(parts[3]) + 1n}`;
    manifest.version = pkg.version = lock.version = lock.packages[''].version = nextVersion;
    versionFiles = [[join(root, 'manifest.json'), manifest], [packagePath, pkg], [lockPath, lock]];
    console.log(`本次插件打包版本：${nextVersion}`);
  }
  await writeFile(join(staging, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
  for (const name of ['web', 'panel']) {
    await copyAssets(join(root, name), join(staging, name));
  }
  await build({
    entryPoints: [join(root, 'main.cjs')],
    outfile: join(staging, 'main.cjs'),
    bundle: true,
    platform: 'node',
    target: 'node22',
    format: 'cjs',
    external: ['bufferutil', 'utf-8-validate'],
    sourcemap: false,
    legalComments: 'eof',
  });
  for (const name of ['web', 'panel']) {
    await build({
      entryPoints: [join(root, name, 'app.js')],
      outfile: join(staging, name, 'app.js'),
      bundle: true,
      platform: 'browser',
      target: ['chrome110', 'safari16'],
      format: 'esm',
      sourcemap: false,
      legalComments: 'eof',
    });
  }

  // Bundle the repository's actual devkit rather than duplicating its installer rules.
  await build({
    entryPoints: [join(repository, 'packages/plugin-devkit/src/index.ts')],
    outfile: join(tooling, 'devkit.mjs'),
    bundle: true,
    platform: 'node',
    target: 'node22',
    format: 'esm',
    alias: { '@pi-desktop/plugin-sdk': join(repository, 'packages/plugin-sdk/src/index.ts') },
  });
  const { check, pack } = await import(pathToFileURL(join(tooling, 'devkit.mjs')).href);
  const result = await check(staging);
  for (const warning of result.warnings) console.warn(`${warning.code}: ${warning.message}`);
  if (!result.ok) {
    for (const error of result.errors) console.error(`${error.code}: ${error.message}`);
    process.exitCode = 1;
  } else if (mode === 'pack') {
    const artifact = await pack(staging, { outDir: join(root, 'dist') });
    // 产物成功生成后才更新源码版本；编译或检查失败不消耗版本号。
    for (const [path, data] of versionFiles) {
      await writeFile(path, `${JSON.stringify(data, null, 2)}\n`);
    }
    await retainArtifacts(join(root, 'dist'), [artifact.packagePath], (entry) => (
      entry.isFile() && entry.name.endsWith('.piplug')
    ));
    console.log(`插件包：${artifact.packagePath}\nSHA-256：${artifact.shasum}`);
  } else {
    console.log(`插件静态打包和 manifest 检查通过：${staging}`);
  }
  if (result.ok) {
    buildSucceeded = true;
    await retainArtifacts(buildRoot, [staging], (entry) => entry.isDirectory() && entry.name.startsWith('plugin-'));
  }
} finally {
  if (!buildSucceeded) await rm(staging, { recursive: true, force: true });
}
